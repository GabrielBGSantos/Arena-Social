package com.example.arenasocial;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import com.example.arenasocial.databinding.ActivityCadastroBinding;
import com.google.android.material.snackbar.Snackbar;
import java.util.Calendar;

public class CadastroActivity extends AppCompatActivity {
    private ActivityCadastroBinding binding;
    private EditText et_senha, et_email, et_nome, et_cpf;
    private Button bt_cadastro;
    private Spinner sp_tipoConta;
    private Button bt_data;
    private Toolbar toolbar;
    BancoDados db = new BancoDados();
    String tipoConta;
    DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initComponents();
        initDatePicker();
        adapterSpinner();
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sp_tipoConta.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                tipoConta = adapterView.getItemAtPosition(position).toString();
                if (tipoConta.equals("Time")){
                    et_cpf.setHint("CNPJ");
                    bt_data.setHint("Data de fundação");
                    et_cpf.setFilters(new InputFilter[]{
                        new InputFilter.LengthFilter(13)
                    });
                }else{
                    et_cpf.setHint("CPF");
                    bt_data.setHint("Data de nascimento");
                    et_cpf.setFilters(new InputFilter[]{
                            new InputFilter.LengthFilter(11)
                    });
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                tipoConta = adapterView.getItemAtPosition(1).toString();
            }
        });

        bt_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = et_nome.getText().toString();
                String email = et_email.getText().toString();
                String senha = et_senha.getText().toString();
                String cpf = et_cpf.getText().toString();
                String dtNasc = bt_data.getText().toString();
                if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || cpf.isEmpty() || tipoConta.isEmpty() || dtNasc.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(v, "Preencha todos os campos",Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                }else{
                    db.cadastrarUsuario(v, email, senha, nome, tipoConta, cpf, dtNasc);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    },3000);
                }
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    private void initComponents(){
        et_nome = binding.etNome;
        et_email = binding.etEmail;
        et_senha = binding.etSenha;
        et_cpf = binding.etCpf;
        bt_cadastro = binding.btCadastrar;
        sp_tipoConta = binding.spTipoConta;
        bt_data = binding.btData;
        toolbar = binding.tbCadastro;
    }

    private void adapterSpinner() {
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                this,android.R.layout.select_dialog_singlechoice){

            @Override
            public boolean isEnabled(int position){
                if(position == 0){
                    return false;

                } else {
                    return true;
                }
            }

            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {

                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;

                if(position == 0){
                    tv.setTextColor(Color.GRAY);

                }else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        spinnerArrayAdapter.add("Tipo de usuario");
        spinnerArrayAdapter.add("Torcedor");
        spinnerArrayAdapter.add("Jogador");
        spinnerArrayAdapter.add("Time");
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        sp_tipoConta.setAdapter(spinnerArrayAdapter);
    }

    private void initDatePicker(){
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = makeDateString(day, month, year);
                bt_data.setText(date);
            }
        };
        Calendar cal = Calendar.getInstance();

        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);

    }

    private String makeDateString(int day, int month, int year){
        return day + " " + getMonthFormat(month) + " " + year;
    }
    private String getMonthFormat(int month){
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEV";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "ABR";
        if(month == 5)
            return "MAI";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AGO";
        if(month == 9)
            return "SET";
        if(month == 10)
            return "OUT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEZ";
        return "JAN";
    }

    public void openDataPicker(View view){
        datePickerDialog.show();
    }

}
