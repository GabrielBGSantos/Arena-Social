package com.example.arenasocial;

import static android.app.PendingIntent.getActivity;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Adapter.CommentAdapter;
import com.example.arenasocial.Adapter.UserAdapter;
import com.example.arenasocial.Adapter.UserAdapterInterface;
import com.example.arenasocial.Classes.Comentario;
import com.example.arenasocial.Classes.Usuario;
import com.example.arenasocial.databinding.ActivityCommentBinding;
import com.example.arenasocial.databinding.ActivityPartsBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class PartsActivity extends AppCompatActivity implements UserAdapterInterface {
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private String eventoId;
    private ArrayList<Usuario> usuarioArrayList;
    private ArrayList<String> idArrayList;
    private UserAdapter userAdapter;
    private FirebaseFirestore db;
    com.example.arenasocial.databinding.ActivityPartsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPartsBinding.inflate(getLayoutInflater());
        initComponents();

        Intent intent = getIntent();
        eventoId = intent.getStringExtra("eventoId");

        searchUser(eventoId);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setContentView(binding.getRoot());
    }

    private void searchUser(String eventoId) {
        db = FirebaseFirestore.getInstance();
        usuarioArrayList = new ArrayList<Usuario>();
        idArrayList = new ArrayList<String>();
        userAdapter = new UserAdapter(this,usuarioArrayList, this);
        recyclerView.setAdapter(userAdapter);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            DocumentReference documentReference = db.collection("Eventos").document(eventoId).collection("Participantes").document(eventoId);
            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            idArrayList.add(document.getData().toString());
                        }
                    }
                }
            });
        }

    }

    private void initComponents() {
        toolbar = binding.tbComment;
        recyclerView = binding.rcComment;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(this, ProfileActivity.class);
        intent.putExtra("userId", usuarioArrayList.get(position).getUserId());
        startActivity(intent);
    }
}
