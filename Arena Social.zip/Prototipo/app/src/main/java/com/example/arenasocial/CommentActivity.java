package com.example.arenasocial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Adapter.CommentAdapter;
import com.example.arenasocial.Classes.Comentario;
import com.example.arenasocial.Classes.Post;
import com.example.arenasocial.databinding.ActivityCadastroBinding;
import com.example.arenasocial.databinding.ActivityCommentBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CommentActivity extends AppCompatActivity {
    EditText addComment;
    Toolbar toolbar;
    private RecyclerView recyclerView;
    private CommentAdapter commentAdapter;
    private ArrayList<Comentario> comentariosArrayList;
    FloatingActionButton enviarComment;
    String postId;
    String idCriador;
    FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
    com.example.arenasocial.databinding.ActivityCommentBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivityCommentBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        initComponents();
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Comentarios");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        postId = intent.getStringExtra("postId");
        idCriador = intent.getStringExtra("idCriador");
        searchComments();

        enviarComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (addComment.getText().toString().isEmpty()){
                    Toast.makeText(CommentActivity.this, "Digite um comentario", Toast.LENGTH_SHORT).show();
                } else {
                    addComment();
                }
            }
        });

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setContentView(binding.getRoot());

    }

    private void addComment(){
        Timestamp timestamp = Timestamp.now();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference reference = db.collection("Comentarios").document(postId).collection(postId).document();
        Map<String,Object> comments = new HashMap<>();
        comments.put("comentario",addComment.getText().toString());
        comments.put("idCriador",firebaseUser.getUid());
        comments.put("timestamp",timestamp);
        reference.set(comments, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                addComment.setText("");
            }
        });
    }
    private void initComponents() {
        toolbar = binding.tbComment;
        addComment = binding.etAddComment;
        enviarComment = binding.btEnviarComment;
        recyclerView = binding.rcComment;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        comentariosArrayList = new ArrayList<>();
        commentAdapter = new CommentAdapter(this, comentariosArrayList);
        recyclerView.setAdapter(commentAdapter);
    }

    private void searchComments() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();{
        if (FirebaseAuth.getInstance().getCurrentUser() != null)
            db.collection("Comentarios").document(postId).collection(postId).orderBy("timestamp").addSnapshotListener(new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                    if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                comentariosArrayList.add(dc.getDocument().toObject(Comentario.class));
                            }
                            commentAdapter.notifyDataSetChanged();
                        }
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        comentariosArrayList.clear();
        super.onDestroy();
    }
}