package com.example.arenasocial.fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.arenasocial.Classes.Evento;
import com.example.arenasocial.MainActivity;
import com.example.arenasocial.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Calendar;

public class EventoFragment extends Fragment {
    EditText etTitulo, etDescricao, etLocal;
    Spinner spTipo;
    Button btData;
    ProgressBar progressBar;
    FloatingActionButton btEnviar;
    DatePickerDialog datePickerDialog;
    String tipo;
    com.example.arenasocial.databinding.FragmentEventoBinding binding;

    Evento evento = new Evento();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = com.example.arenasocial.databinding.FragmentEventoBinding.inflate(inflater, container, false);
        initComponents();
        initDatePicker();
        adapterSpinner();

        btData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEvDataPicker(getView());
            }
        });
        spTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                tipo = adapterView.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tipo = "";
            }
        });

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String titulo = etTitulo.getText().toString();
                String descricao = etDescricao.getText().toString();
                String data = btData.getText().toString();
                String local = etLocal.getText().toString();
                String idCriador = FirebaseAuth.getInstance().getCurrentUser().getUid();
                if (titulo.isEmpty() || descricao.isEmpty() || data.isEmpty() || tipo.isEmpty() || local.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(v, "Preencha todos os campos",Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                }else{
                    evento.salvarDadosEvento(titulo, descricao, data, tipo, local, idCriador);
                }
                progressBar.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        fecharTela();
                    }},3000);
            }
        });

        return binding.getRoot();
    }

    private void adapterSpinner() {
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(),R.layout.spinnerev_item){
        };
        spinnerArrayAdapter.add("Confraternização");
        spinnerArrayAdapter.add("Pelada");
        spinnerArrayAdapter.add("Assistir a uma partida");
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);

        spTipo.setAdapter(spinnerArrayAdapter);
    }

    private void initDatePicker(){
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                month = month + 1;
                String date = makeDateString(day, month, year);
                btData.setText(date);
            }
        };
        Calendar cal = Calendar.getInstance();

        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(getActivity(), style, dateSetListener, year, month, day);

    }

    private String makeDateString(int day, int month, int year){
        return day + " " + getMonthFormat(month) + " " + year;
    }
    private String getMonthFormat(int month){
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEV";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "ABR";
        if(month == 5)
            return "MAI";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AGO";
        if(month == 9)
            return "SET";
        if(month == 10)
            return "OUT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEZ";
        return "JAN";
    }

    public void openEvDataPicker(View view){
        datePickerDialog.show();
    }

    private void fecharTela(){
        Intent intent = new Intent(getActivity(), MainActivity.class);
        getActivity().finish();
        startActivity(intent);
    }
    private void initComponents(){
        spTipo = binding.spTipoEvento;
        btData = binding.btDataEv;
        btEnviar = binding.btEnviar;
        etTitulo = binding.etTituloEvento;
        etDescricao = binding.etDescricao;
        etLocal = binding.etLocalEvento;
        progressBar = binding.progressbar;
    }

}