package com.example.arenasocial.Classes;

import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Post {
    String postId, descricao, idCriador, postUri, data, local, tipoEv, titulo;
    int tipo;
    public Post(){

    }

    public Post(String postId, String descricao, String idCriador, String postUri, String data, String local, String tipoEv, String titulo, int tipo) {
        this.postId = postId;
        this.descricao = descricao;
        this.idCriador = idCriador;
        this.postUri = postUri;
        this.data = data;
        this.local = local;
        this.tipoEv = tipoEv;
        this.titulo = titulo;
        this.tipo = tipo;
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getIdCriador() {
        return idCriador;
    }

    public void setIdCriador(String idCriador) {
        this.idCriador = idCriador;
    }

    public String getPostUri() {
        return postUri;
    }

    public void setPostUri(String postUri) {
        this.postUri = postUri;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getTipoEv() {
        return tipoEv;
    }

    public void setTipoEv(String tipoEv) {
        this.tipoEv = tipoEv;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void salvarDadosPost(String descricao, String idCriador, int tipo){
        Timestamp timestamp = Timestamp.now();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String,Object> posts = new HashMap<>();
        posts.put("descricao",descricao);
        posts.put("idCriador",idCriador);
        posts.put("tipo",tipo);
        posts.put("timestamp",timestamp);
        String postId = db.collection("Posts").document().getId();
        posts.put("postId",postId);
        DocumentReference documentReference = db.collection("Posts").document(postId);
        documentReference.set(posts).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db","Sucesso ao salvar os dados");
                criarLikes(postId);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
            }
        });
    }

    public void salvarPostImg(String descricao, Uri postUri, String idCriador, int tipo){
        Timestamp timestamp = Timestamp.now();
        String filename = UUID.randomUUID().toString();
        final StorageReference ref = FirebaseStorage.getInstance().getReference("/postsImgs/" + filename);
        ref.putFile(postUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Log.i("Usr uri:", uri.toString());
                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        Map<String,Object> posts = new HashMap<>();
                        posts.put("descricao",descricao);
                        posts.put("idCriador",idCriador);
                        posts.put("tipo",tipo);
                        posts.put("postUri",uri);
                        posts.put("timestamp",timestamp);
                        String postId = db.collection("Posts").document().getId();
                        posts.put("postId",postId);
                        DocumentReference documentReference = db.collection("Posts").document(postId);
                        documentReference.set(posts).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Log.d("db","Sucesso ao salvar os dados");
                                criarLikes(postId);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
                            }
                        });
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("Teste", e.getMessage(), e);
            }
        });
    }

    public void salvarEventoPost(String titulo, String descricao, String data, String tipoEv, String local, String idCriador,String eventoId, int tipo){
        Timestamp timestamp = Timestamp.now();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String,Object> posts = new HashMap<>();
        posts.put("titulo",titulo);
        posts.put("descricao",descricao);
        posts.put("data",data);
        posts.put("tipoEv",tipoEv);
        posts.put("local",local);
        posts.put("idCriador",idCriador);
        posts.put("tipo",tipo);
        posts.put("timestamp",timestamp);
        posts.put("postId",eventoId);
        DocumentReference documentReference = db.collection("Posts").document(eventoId);
        documentReference.set(posts).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db","Sucesso ao salvar os dados");
                criarLikes(postId);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
            }
        });
        criarLikes(eventoId);
    }
    public void criarLikes(String postId){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> likes = new HashMap<>();
        DocumentReference documentReference = db.collection("Likes").document(postId);
        documentReference.set(likes).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db", "Sucesso ao salvar os dados");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
            }
        });
    }
}
