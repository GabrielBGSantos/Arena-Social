package com.example.arenasocial.Adapter;

public interface UserAdapterInterface {
    void onItemClick(int position);
}
