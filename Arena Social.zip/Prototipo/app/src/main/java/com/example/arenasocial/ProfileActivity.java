package com.example.arenasocial;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Adapter.PostAdapter;
import com.example.arenasocial.Classes.Post;
import com.example.arenasocial.databinding.ActivityProfileBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    private com.example.arenasocial.databinding.ActivityProfileBinding binding;
    private Toolbar toolbar;
    private String userId;
    private FirebaseFirestore fs;
    private ArrayList<Post> postArrayList = new ArrayList<Post>();
    private PostAdapter postAdapter = new PostAdapter(this, postArrayList);
    private RecyclerView recyclerView;
    private TextView nomeUser, tvTime, tvModalidade, tvShowModalidade;
    private CircleImageView prfImg,teamImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        userId = intent.getStringExtra("userId");
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        initComponents();
        postArrayList.clear();
        searchPosts();
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setContentView(binding.getRoot());
    }

    private void searchPosts(){
        fs = FirebaseFirestore.getInstance();
        fs.collection("Posts").orderBy("timestamp").whereEqualTo("idCriador", userId).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if(error != null){
                    Log.e("Firestore error", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()){
                    if (dc.getType() == DocumentChange.Type.ADDED){
                        postArrayList.add(dc.getDocument().toObject(Post.class));
                    }
                    postAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        DocumentReference documentReference = fs.collection("Usuarios").document(userId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if(documentSnapshot != null){
                    nomeUser.setText(documentSnapshot.getString("nome"));
                    if(documentSnapshot.getString("prfUri") != null) {
                        Picasso.get().load(documentSnapshot.getString("prfUri")).into(prfImg);
                    }else{
                        prfImg.setImageResource(R.drawable.noprfoto);
                    }
                    if(documentSnapshot.getString("tipo").equals("Jogador")){
                        tvTime.setText("Time que joga:");
                        tvModalidade.setText("Posição:");
                    }
                    if(documentSnapshot.getString("modalidade") != null) {
                        tvShowModalidade.setText(documentSnapshot.getString("modalidade"));
                    }
                    if(documentSnapshot.getString("tipo").equals("Time")){
                        tvTime.setText("Proximo jogo:");
                    }
                }
            }
        });
        DocumentReference documentRef = fs.collection("Usuarios").document(userId);
        documentRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if(documentSnapshot != null && documentSnapshot.getString("timeFav") != null){
                    fs.collection("Usuarios").whereEqualTo("nome", documentSnapshot.getString("timeFav")).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Picasso.get().load(document.getString("prfUri")).into(teamImg);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    private void initComponents() {
        toolbar = binding.tbToolbar;
        nomeUser = binding.tvNomeUser;
        tvTime = binding.tvTimeFav;
        tvModalidade = binding.tvModalidade;
        tvShowModalidade = binding.tvShowModalidade;
        prfImg = binding.userImg;
        teamImg = binding.btIvTeam;
        recyclerView = binding.rcPrf;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setAdapter(postAdapter);
        recyclerView.setLayoutManager(linearLayoutManager);
    }
}