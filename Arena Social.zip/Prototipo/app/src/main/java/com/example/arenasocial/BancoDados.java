package com.example.arenasocial;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;

import com.example.arenasocial.databinding.ActivityCadastroBinding;
import com.example.arenasocial.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.net.URI;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Handler;

public class BancoDados {
    String usuarioID;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    protected void cadastrarUsuario(View v, String email, String senha, String nome, String tipoC, String cpf, String dtNasc){
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Snackbar snackbar = Snackbar.make(v, "Cadastro realizado com sucesso",Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                    salvarDadosUsuario(nome, tipoC, cpf, dtNasc);
                } else{
                    String erro;
                    try{
                        throw task.getException();
                    }catch (FirebaseAuthWeakPasswordException e){
                        erro = "Digite uma senha com no minimo 6 caracteres";
                    }catch(FirebaseAuthUserCollisionException e){
                        erro = "E-mail já cadastrado";
                    }catch (FirebaseAuthInvalidCredentialsException e){
                        erro = "E-mail invalido";
                    }catch (Exception e){
                        erro = "Erro ao cadastrar usuario";
                    }
                    Snackbar snackbar = Snackbar.make(v, erro,Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                }
            }
        });
    }

    protected void salvarDadosUsuario(String nome, String tipoC, String cpf, String dtNasc){
        Map<String,Object> usuarios = new HashMap<>();
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        usuarios.put("nome",nome);
        usuarios.put("tipo",tipoC);
        usuarios.put("cpf", cpf);
        usuarios.put("Data_de_nascimento", dtNasc);
        usuarios.put("userId", usuarioID);
        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.set(usuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db","Sucesso ao salvar os dados");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
            }
        });
    }

    public void deslogar(){
        FirebaseAuth.getInstance().signOut();
    }

    public void saveUsrPhoto(Uri photo){
        String filename = UUID.randomUUID().toString();
        final StorageReference ref = FirebaseStorage.getInstance().getReference("/prfImgs/" + filename);
        ref.putFile(photo).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                        Log.i("Usr uri:", uri.toString());
                        Map<String,Object> usuarios = new HashMap<>();
                        usuarios.put("prfUri", uri);
                        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
                        documentReference.update(usuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Log.d("db","Sucesso ao salvar os dados");
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("db_error", "Erro ao salvar os dados" + e.toString());
                            }
                        });
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("Teste", e.getMessage(), e);
            }
        });
    }
    public void saveModalidade(String modalidade){
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Map<String,Object> modal = new HashMap<>();
        modal.put("modalidade", modalidade);
        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.update(modal).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db","Sucesso ao salvar os dados");
            }
        });
    }
}