package com.example.arenasocial;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SearchView;

import com.example.arenasocial.Adapter.UserAdapter;
import com.example.arenasocial.Adapter.UserAdapterInterface;
import com.example.arenasocial.Classes.Usuario;
import com.example.arenasocial.databinding.ActivityPostBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SelecteamActivity extends AppCompatActivity implements UserAdapterInterface {
    com.example.arenasocial.databinding.ActivitySelecteamBinding binding;
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private ArrayList<Usuario> usuarioArrayList;
    private FirebaseFirestore db;
    private SearchView src;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = com.example.arenasocial.databinding.ActivitySelecteamBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initComponents();
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        searchTeam("");
        src.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchTeam(s.toUpperCase());
                return false;
            }
            @Override
            public boolean onQueryTextChange(String s) {
                searchTeam(s.toUpperCase());
                return false;
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void searchTeam(String s){
        db = FirebaseFirestore.getInstance();
        usuarioArrayList = new ArrayList<Usuario>();
        userAdapter = new UserAdapter(SelecteamActivity.this,usuarioArrayList,this);
        recyclerView.setAdapter(userAdapter);

        db.collection("Usuarios").orderBy("nome").whereEqualTo("tipo","Time").startAt(s).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if(error != null){
                    Log.e("Firestore error", error.getMessage());
                    return;
                }
                usuarioArrayList.clear();
                for (DocumentChange dc : value.getDocumentChanges()){
                    if (dc.getType() == DocumentChange.Type.ADDED){
                        usuarioArrayList.add(dc.getDocument().toObject(Usuario.class));
                    }
                    userAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void initComponents() {
        recyclerView = binding.rcSelcTeam;
        src = binding.srcTeam;
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(SelecteamActivity.this));
        toolbar = binding.tbSrc;
    }

    @Override
    public void onItemClick(int position) {
        String usuarioID;
        if (Objects.equals(usuarioArrayList.get(position).getTipo(), "Time")) {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Map<String,Object> usuarios = new HashMap<>();
            usuarios.put("timeFav", usuarioArrayList.get(position).getNome());
            usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
            documentReference.update(usuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d("db","Sucesso ao salvar os dados");
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("db_error", "Erro ao salvar os dados" + e.toString());
                }
            });
            finish();
        }
    }
}