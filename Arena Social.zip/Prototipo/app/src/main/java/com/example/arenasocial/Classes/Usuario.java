package com.example.arenasocial.Classes;

import java.util.ArrayList;
import java.util.Date;

public class Usuario {
    String userId, nome, cpf, prfUri, Data_de_nascimento, tipo;
    boolean verificado;
    ArrayList<String> listAmigos = new ArrayList<>();
    ArrayList<String> listaBloqueados = new ArrayList<>();
    ArrayList<String> listaEventos = new ArrayList<>();
    ArrayList<String> listaPublicaçoes = new ArrayList<>();
    ArrayList<String> listaChamado = new ArrayList<>();

    public Usuario(){}

    public Usuario(String nome, String cpf, String prfUri, String data_de_nascimento, String tipo, String userId) {
        this.nome = nome;
        this.cpf = cpf;
        this.prfUri = prfUri;
        Data_de_nascimento = data_de_nascimento;
        this.tipo = tipo;
        this.userId = userId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getPrfUri() {
        return prfUri;
    }

    public void setPrfUri(String prfUri) {
        this.prfUri = prfUri;
    }

    public String getData_de_nascimento() {
        return Data_de_nascimento;
    }

    public void setData_de_nascimento(String data_de_nascimento) {
        Data_de_nascimento = data_de_nascimento;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
