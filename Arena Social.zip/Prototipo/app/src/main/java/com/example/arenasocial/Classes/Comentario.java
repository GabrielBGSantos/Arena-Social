package com.example.arenasocial.Classes;

public class Comentario {
    String comentario, idCriador;

    public Comentario() {

    }

    public Comentario(String comentario, String idCriador) {
        this.comentario = comentario;
        this.idCriador = idCriador;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getIdCriador() {
        return idCriador;
    }

    public void setIdCriador(String idCriador) {
        this.idCriador = idCriador;
    }
}
