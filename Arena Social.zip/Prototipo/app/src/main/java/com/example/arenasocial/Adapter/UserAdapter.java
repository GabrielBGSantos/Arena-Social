package com.example.arenasocial.Adapter;

import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Classes.Usuario;
import com.example.arenasocial.R;
import com.example.arenasocial.fragments.ProfileFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import org.checkerframework.checker.units.qual.N;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder>{
    private final UserAdapterInterface userAdapterInterface;
    Context context;
    ArrayList<Usuario> usuarioArrayList;

    public UserAdapter(Context context, ArrayList<Usuario> usuarioArrayList, UserAdapterInterface userAdapterInterface) {
        this.context = context;
        this.usuarioArrayList = usuarioArrayList;
        this.userAdapterInterface = userAdapterInterface;
    }

    @NonNull
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(context).inflate(R.layout.user_item,parent,false);

        return new ViewHolder(v, userAdapterInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.ViewHolder holder, int position) {
        Usuario usuario = usuarioArrayList.get(position);
        holder.username.setText(usuario.getNome());
        holder.tipoConta.setText(usuario.getTipo());
        if (usuario.getPrfUri() == null) {
            if (usuario.getTipo().equals("Time")) {
                holder.imgPrf.setImageResource(R.drawable.noteamphoto);
            }else{
                holder.imgPrf.setImageResource(R.drawable.noprfoto);
            }
        }else{
            Picasso.get().load(usuario.getPrfUri()).into(holder.imgPrf);
        }
    }

    @Override
    public int getItemCount() {
        return usuarioArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView username,tipoConta;
        CircleImageView imgPrf;
        public ViewHolder(@NonNull View itemView, UserAdapterInterface userAdapterInterface){
            super(itemView);
            username = itemView.findViewById(R.id.username);
            tipoConta = itemView.findViewById(R.id.tipoConta);
            imgPrf = itemView.findViewById(R.id.img_prf);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(userAdapterInterface != null){
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION){
                            userAdapterInterface.onItemClick(pos);
                        }
                    }
                }
            });
        }
    }
}
