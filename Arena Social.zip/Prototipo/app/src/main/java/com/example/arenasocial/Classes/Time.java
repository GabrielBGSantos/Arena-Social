package com.example.arenasocial.Classes;

import java.util.ArrayList;
import java.util.Date;

public class Time extends Usuario{
    ArrayList<String> listaJogadores = new ArrayList<>();
    ArrayList<String> listaTitulos = new ArrayList<>();
    ArrayList<String> resultados = new ArrayList<>();


}
