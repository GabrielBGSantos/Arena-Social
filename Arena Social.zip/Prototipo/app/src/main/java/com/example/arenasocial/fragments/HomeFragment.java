package com.example.arenasocial.fragments;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.arenasocial.Adapter.PostAdapter;
import com.example.arenasocial.Classes.Post;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private ArrayList<Post> postArrayList = new ArrayList<Post>();
    private PostAdapter postAdapter = new PostAdapter(getActivity(), postArrayList);
    private RecyclerView recyclerView;
    private FirebaseFirestore db;
    private SwipeRefreshLayout swipeRefreshLayout;
    com.example.arenasocial.databinding.FragmentHomeBinding binding;

    public HomeFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = com.example.arenasocial.databinding.FragmentHomeBinding.inflate(inflater, container, false);

        initComponents();
        searchPosts();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
           public void onRefresh() {
                postAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        return binding.getRoot();
    }

    private void searchPosts() {
        postArrayList.clear();
        db = FirebaseFirestore.getInstance();
        db.collection("Posts").orderBy("timestamp").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("Firestore error", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()) {
                    if (dc.getType() == DocumentChange.Type.ADDED) {
                        postArrayList.add(dc.getDocument().toObject(Post.class));
                    }
                    postAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void initComponents() {
        recyclerView = binding.rcHome;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setAdapter(postAdapter);
        recyclerView.setLayoutManager(linearLayoutManager);
        swipeRefreshLayout = binding.swipeRefreshHome;
    }

    @Override
    public void onDestroyView() {
        postArrayList.clear();
        postAdapter.notifyDataSetChanged();
        super.onDestroyView();
    }
}