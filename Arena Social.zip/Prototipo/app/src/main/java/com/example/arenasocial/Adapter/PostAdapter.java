package com.example.arenasocial.Adapter;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Classes.Post;
import com.example.arenasocial.Classes.Usuario;
import com.example.arenasocial.CommentActivity;
import com.example.arenasocial.PartsActivity;
import com.example.arenasocial.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.AggregateQuery;
import com.google.firebase.firestore.AggregateQuerySnapshot;
import com.google.firebase.firestore.AggregateSource;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    final Context context;
    public ArrayList<Post> postArrayList;
    String usuarioId, usuarioAt;
    FirebaseFirestore fs = FirebaseFirestore.getInstance();
    public PostAdapter(Context context, ArrayList<Post> postArrayList) {
        this.context = context;
        this.postArrayList = postArrayList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 0) {
            return new ViewHolderText(LayoutInflater.from(parent.getContext()).inflate(R.layout.post_text_item, parent, false));
        } else if (viewType == 1) {
            return new ViewHolderImg(LayoutInflater.from(parent.getContext()).inflate(R.layout.post_img_item, parent, false));
        } else {
            return new ViewHolderEv(LayoutInflater.from(parent.getContext()).inflate(R.layout.post_evento_item, parent, false));
        }
    }

    @Override
    public int getItemViewType(int position) {
        return postArrayList.get(position).getTipo();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Post post = postArrayList.get(position);
        usuarioId = post.getIdCriador();
        usuarioAt = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DocumentReference documentReference = fs.collection("Usuarios").document(usuarioId);
        if (getItemViewType(position) == 0) {
            documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                    if (documentSnapshot != null) {
                        ((ViewHolderText) holder).username.setText(documentSnapshot.getString("nome"));
                        if (documentSnapshot.getString("prfUri") != null) {
                            Picasso.get().load(documentSnapshot.getString("prfUri")).into(((ViewHolderText) holder).imgPrf);
                        }else{
                            ((ViewHolderText) holder).imgPrf.setImageResource(R.drawable.noprfoto);
                        }
                    }
                }
            });
            ((ViewHolderText) holder).descricao.setText(post.getDescricao());
            isLiked(post.getPostId(), ((ViewHolderText) holder).btLike);
            nLikes(post.getPostId(), ((ViewHolderText) holder).nLikes, ((ViewHolderText) holder).nComments);

            ((ViewHolderText) holder).btLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    like(post.getPostId(), usuarioAt, ((ViewHolderText) holder).btLike);
                }
            });

            ((ViewHolderText) holder).btComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openComments(((ViewHolderText) holder).btComment.getContext(), post.getPostId(), post.getIdCriador());
                }
            });

        } else if (getItemViewType(position) == 1) {
            documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                    if (documentSnapshot != null) {
                        ((ViewHolderImg) holder).username.setText(documentSnapshot.getString("nome"));
                        if (documentSnapshot.getString("prfUri") != null) {
                            Picasso.get().load(documentSnapshot.getString("prfUri")).into(((ViewHolderImg) holder).imgPrf);
                        }else {
                            ((ViewHolderImg) holder).imgPrf.setImageResource(R.drawable.noprfoto);
                        }
                    }
                }
            });
            ((ViewHolderImg) holder).descricao.setText(post.getDescricao());
            Picasso.get().load(post.getPostUri()).into(((ViewHolderImg) holder).imgPost);
            isLiked(post.getPostId(), ((ViewHolderImg) holder).btLike);
            nLikes(post.getPostId(), ((ViewHolderImg) holder).nLikes, ((ViewHolderImg) holder).nComments);
            ((ViewHolderImg) holder).btLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    like(post.getPostId(), usuarioAt, ((ViewHolderImg) holder).btLike);
                }
            });
            ((ViewHolderImg) holder).btComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openComments(((ViewHolderImg) holder).btComment.getContext(), post.getPostId(), post.getIdCriador());
                }
            });

        } else if (getItemViewType(position) == 2) {
            documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                    if (documentSnapshot != null) {
                        ((ViewHolderEv) holder).username.setText(documentSnapshot.getString("nome"));
                        if (documentSnapshot.getString("prfUri") != null) {
                            Picasso.get().load(documentSnapshot.getString("prfUri")).into(((ViewHolderEv) holder).imgPrf);
                        }else {
                            ((ViewHolderEv) holder).imgPrf.setImageResource(R.drawable.noprfoto);
                        }
                    }
                }
            });
            ((ViewHolderEv) holder).titulo.setText(post.getTitulo());
            ((ViewHolderEv) holder).descricao.setText(post.getDescricao());
            ((ViewHolderEv) holder).tipoEv.setText(post.getTipoEv());
            ((ViewHolderEv) holder).dataEv.setText(post.getData());
            ((ViewHolderEv) holder).localEv.setText(post.getLocal());
            isPart(post.getPostId(), ((ViewHolderEv) holder).btParticiparEv, ((ViewHolderEv) holder).nParts);
            isLiked(post.getPostId(), ((ViewHolderEv) holder).btLike);
            nLikes(post.getPostId(), ((ViewHolderEv) holder).nLikes, ((ViewHolderEv) holder).nComments);
            ((ViewHolderEv) holder).btLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    like(post.getPostId(), usuarioAt, ((ViewHolderEv) holder).btLike);
                }
            });
            ((ViewHolderEv) holder).btComment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openComments(((ViewHolderEv) holder).btComment.getContext(), post.getPostId(), post.getIdCriador());
                }
            });
            ((ViewHolderEv) holder).btParticiparEv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    partEv(post.getPostId(), usuarioAt, ((ViewHolderEv) holder).btParticiparEv);
                }
            });
            ((ViewHolderEv) holder).parts.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openParts(((ViewHolderEv) holder).parts.getContext(), post.getPostId());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return postArrayList.size();
    }

    public static class ViewHolderText extends RecyclerView.ViewHolder {
        TextView username, descricao, nLikes, nComments;
        CircleImageView imgPrf;
        ImageButton btLike, btComment;
        public ViewHolderText(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.tv_usernamePt);
            descricao = itemView.findViewById(R.id.tv_descricaoPt);
            imgPrf = itemView.findViewById(R.id.prf_imgPt);
            btLike = itemView.findViewById(R.id.bt_likePt);
            nLikes = itemView.findViewById(R.id.tv_nlikesPt);
            btComment = itemView.findViewById(R.id.bt_cmtPt);
            nComments = itemView.findViewById(R.id.tv_nCommentsPt);
        }

    }

    public static class ViewHolderImg extends RecyclerView.ViewHolder {
        TextView username, descricao, nLikes, nComments;
        CircleImageView imgPrf;
        ImageView imgPost;
        ImageButton btLike, btComment;
        public ViewHolderImg(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.usernameI);
            descricao = itemView.findViewById(R.id.descricaoI);
            imgPrf = itemView.findViewById(R.id.prf_imgI);
            imgPost = itemView.findViewById(R.id.imgPostI);
            btLike = itemView.findViewById(R.id.bt_likeI);
            nLikes = itemView.findViewById(R.id.tv_nlikesI);
            btComment = itemView.findViewById(R.id.bt_CmtI);
            nComments = itemView.findViewById(R.id.tv_nCommentsI);
        }

    }

    public static class ViewHolderEv extends RecyclerView.ViewHolder {
        TextView username, descricao, titulo, dataEv,localEv, tipoEv, nLikes, nComments, nParts, parts;
        CircleImageView imgPrf;
        ImageButton btLike, btComment;
        Button btParticiparEv;
        public ViewHolderEv(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.tv_usernameEv);
            descricao = itemView.findViewById(R.id.tv_descricaoEv);
            imgPrf = itemView.findViewById(R.id.prf_imgEv);
            titulo = itemView.findViewById(R.id.tv_tituloEvento);
            localEv = itemView.findViewById(R.id.tv_localEv);
            dataEv = itemView.findViewById(R.id.tv_dataEv);
            tipoEv = itemView.findViewById(R.id.tv_tipoEv);
            btLike = itemView.findViewById(R.id.bt_likeEv);
            nLikes = itemView.findViewById(R.id.tv_nlikesEv);
            btComment = itemView.findViewById(R.id.bt_cmtEv);
            nComments = itemView.findViewById(R.id.tv_nCommentsEv);
            btParticiparEv = itemView.findViewById(R.id.bt_participarEv);
            nParts = itemView.findViewById(R.id.tv_nPartEv);
            parts = itemView.findViewById(R.id.tv_PartEv);
        }
    }
    private void like(String postId, String usuarioAt, ImageButton btLike){
        Map<String, Object> likes = new HashMap<>();
        DocumentReference documentReference = fs.collection("Likes").document(postId);
        if (btLike.getTag().equals("noLike")) {
            likes.put(usuarioAt, true);
            documentReference.update(likes).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d("db", "Sucesso ao salvar os dados");
                }
            });

        }else {
            likes.put(usuarioAt, FieldValue.delete());
            documentReference.update(likes).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d("db", "Sucesso ao salvar os dados");
                }
            });
        }
    }
    private void partEv(String postId, String usuarioAt, Button btParticiparEv){
        Map<String, Object> evento = new HashMap<>();
        DocumentReference documentReference = fs.collection("Eventos").document(postId).collection("Participantes").document(postId);
        if (btParticiparEv.getTag().equals("participar")) {
            evento.put(usuarioAt, usuarioAt);
            documentReference.update(evento).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d("db", "Sucesso ao salvar os dados");
                }
            });

        }else {
            evento.put(usuarioAt, FieldValue.delete());
            documentReference.update(evento).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Log.d("db", "Sucesso ao salvar os dados");
                }
            });
        }
    }
    private void openComments(Context nContext, String postId, String IdCriador){
        Intent intent = new Intent(nContext, CommentActivity.class);
        intent.putExtra("postId", postId);
        intent.putExtra("usuarioId", IdCriador);
        nContext.startActivity(intent);
    }

    private void openParts(Context nContext, String eventoId){
        Intent intent = new Intent(nContext, PartsActivity.class);
        intent.putExtra("eventoId", eventoId);
        nContext.startActivity(intent);
    }

    private void isLiked(String postId, ImageButton imageButton) {
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DocumentReference documentReference = fs.collection("Likes").document(postId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if(FirebaseAuth.getInstance().getCurrentUser() != null){
                if (value.contains(firebaseUser.getUid())) {
                    imageButton.setImageResource(R.drawable.ic_like);
                    imageButton.setTag("liked");
                } else {
                    imageButton.setImageResource(R.drawable.ic_nolike);
                    imageButton.setTag("noLike");
                    }
                }
            }
        });
    }

    private void nLikes(String postId, TextView likes, TextView nComments) {
        DocumentReference documentReference = fs.collection("Likes").document(postId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (FirebaseAuth.getInstance().getCurrentUser() != null){
                    if (value.exists()) {
                        Map<String, Object> data = value.getData();
                        likes.setText(String.valueOf(data.size()));
                    }
                }
            }
        });
        Query query = fs.collection("Comentarios").document(postId).collection(postId);
        AggregateQuery countQuery = query.count();
        countQuery.get(AggregateSource.SERVER).addOnCompleteListener(new OnCompleteListener<AggregateQuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<AggregateQuerySnapshot> task) {
                if (task.isSuccessful()) {
                    AggregateQuerySnapshot snapshot = task.getResult();
                    nComments.setText(String.valueOf(snapshot.getCount()));
                }
            }
        });

    }
    private void isPart(String postId, Button button, TextView parts){
        FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DocumentReference documentReference = fs.collection("Eventos").document(postId).collection("Participantes").document(postId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if(FirebaseAuth.getInstance().getCurrentUser() != null){
                    if (value.contains(firebaseUser.getUid())) {
                        button.setBackgroundResource(R.drawable.button_evento_part);
                        button.setText("Participando");
                        button.setTag("participando");
                    } else {
                        button.setBackgroundResource(R.drawable.button_evento);
                        button.setText(R.string.participar_do_evento);
                        button.setTag("participar");
                    }
                }
            }
        });
        DocumentReference documentReferenceP= fs.collection("Eventos").document(postId).collection("Participantes").document(postId);
        documentReferenceP.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if (FirebaseAuth.getInstance().getCurrentUser() != null){
                    if (value.exists()) {
                        Map<String, Object> data = value.getData();
                        parts.setText(String.valueOf(data.size()));
                    }
                }
            }
        });
    }
}