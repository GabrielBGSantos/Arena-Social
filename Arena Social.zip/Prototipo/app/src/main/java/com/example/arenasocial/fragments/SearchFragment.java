package com.example.arenasocial.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.example.arenasocial.Adapter.UserAdapter;
import com.example.arenasocial.Adapter.UserAdapterInterface;
import com.example.arenasocial.Classes.Usuario;

import com.example.arenasocial.CommentActivity;
import com.example.arenasocial.ProfileActivity;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class SearchFragment extends Fragment implements UserAdapterInterface {
    com.example.arenasocial.databinding.FragmentSearchBinding binding;
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private ArrayList<Usuario> usuarioArrayList;
    private FirebaseFirestore db;
    private SearchView src;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = com.example.arenasocial.databinding.FragmentSearchBinding.inflate(inflater, container, false);
        initComponents();
        searchUser("");

        src.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchUser(s.toUpperCase());
                return false;
            }
            @Override
            public boolean onQueryTextChange(String s) {
                searchUser(s.toUpperCase());
                return false;
            }
        });
        return binding.getRoot();
    }

    private void searchUser(String s) {
        db = FirebaseFirestore.getInstance();
        usuarioArrayList = new ArrayList<Usuario>();
        userAdapter = new UserAdapter(getActivity(),usuarioArrayList, this);
        recyclerView.setAdapter(userAdapter);

          db.collection("Usuarios").orderBy("nome").startAt(s).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if(error != null){
                    Log.e("Firestore error", error.getMessage());
                    return;
                }
                usuarioArrayList.clear();
                for (DocumentChange dc : value.getDocumentChanges()){
                    if (dc.getType() == DocumentChange.Type.ADDED){
                        usuarioArrayList.add(dc.getDocument().toObject(Usuario.class));
                    }
                    userAdapter.notifyDataSetChanged();
                }
            }
        });

    }

    private void initComponents(){
        src = binding.etSearch;
        recyclerView = binding.rcSrc;
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(getContext(), ProfileActivity.class);
        intent.putExtra("userId", usuarioArrayList.get(position).getUserId());
        startActivity(intent);
    }
}