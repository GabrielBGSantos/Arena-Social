package com.example.arenasocial.fragments;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Handler;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.example.arenasocial.Classes.Post;
import com.example.arenasocial.MainActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

public class PostFragment extends Fragment {
    EditText descricao;
    FloatingActionButton btGal, btEnviar;
    ImageView postImg;
    ProgressBar progressBar;
    Uri imgUri;
    com.example.arenasocial.databinding.FragmentPostBinding binding;
    Post post = new Post();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = com.example.arenasocial.databinding.FragmentPostBinding.inflate(inflater, container, false);
        initComponents();
        btGal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 3);
            }
        });

            btEnviar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(descricao.getText().toString().isEmpty()){
                        Snackbar snackbar = Snackbar.make(v, "Digite algo no seu post",Snackbar.LENGTH_SHORT);
                        snackbar.setBackgroundTint(Color.WHITE);
                        snackbar.setTextColor(Color.BLACK);
                        snackbar.show();
                    }else {
                    if (imgUri == null) {
                        post.salvarDadosPost(descricao.getText().toString(), FirebaseAuth.getInstance().getCurrentUser().getUid(),0);
                    }else{
                        post.salvarPostImg(descricao.getText().toString(), imgUri, FirebaseAuth.getInstance().getCurrentUser().getUid(),1);
                    }
                    progressBar.setVisibility(View.VISIBLE);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                                fecharTela();
                            }},3000);
                    }
                }
            });
        return binding.getRoot();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            imgUri = selectedImage;
            postImg.setImageURI(selectedImage);
        }
    }
    private void fecharTela(){
        Intent intent = new Intent(getActivity(), MainActivity.class);
        getActivity().finish();
        startActivity(intent);
    }
    private void initComponents(){
        descricao = binding.etPost;
        btGal = binding.btGallery;
        btEnviar = binding.btEnviar;
        postImg = binding.postImg;
        progressBar = binding.progressbar;
    }

}