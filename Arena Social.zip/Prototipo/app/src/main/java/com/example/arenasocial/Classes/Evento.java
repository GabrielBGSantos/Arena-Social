package com.example.arenasocial.Classes;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class Evento {
    Post post = new Post();
    public void salvarDadosEvento(String titulo, String descricao, String data, String tipoEv, String local, String idCriador){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String,Object> eventos = new HashMap<>();
        eventos.put("titulo",titulo);
        eventos.put("descricao",descricao);
        eventos.put("data",data);
        eventos.put("tipo",tipoEv);
        eventos.put("local",local);
        eventos.put("idCriador",idCriador);
        String eventoId = db.collection("Eventos").document().getId();
        DocumentReference documentReference = db.collection("Eventos").document(eventoId);
        documentReference.set(eventos).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                post.salvarEventoPost(titulo, descricao, data, tipoEv, local, idCriador, eventoId,2);
            }
        });
        DocumentReference reference = db.collection("Eventos").document(eventoId).collection("Participantes").document(eventoId);
        String usuarioAt = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Map<String,Object> event = new HashMap<>();
        event.put(usuarioAt,true);
        reference.set(event, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.d("db","Sucesso ao salvar os dados");
            }
        });
    }
}
