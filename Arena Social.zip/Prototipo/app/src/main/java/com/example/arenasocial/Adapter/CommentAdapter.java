package com.example.arenasocial.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.arenasocial.Classes.Comentario;
import com.example.arenasocial.Classes.Usuario;
import com.example.arenasocial.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder>{
    private Context context;
    private ArrayList<Comentario> comentArrayList;
    private FirebaseUser firebaseUser;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    public CommentAdapter(Context context, ArrayList<Comentario> comentArrayList) {
        this.context = context;
        this.comentArrayList = comentArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.comment_item, parent, false);
        return new CommentAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Comentario comentario = comentArrayList.get(position);
        holder.descricao_comment.setText((comentario.getComentario()));
        getUserInfo(holder.img_prfComment,holder.username_comment, comentario.getIdCriador());
    }

    @Override
    public int getItemCount() {
        return comentArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView img_prfComment;
        public TextView username_comment, descricao_comment;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img_prfComment = itemView.findViewById(R.id.img_prfComment);
            username_comment = itemView.findViewById(R.id.username_comment);
            descricao_comment = itemView.findViewById(R.id.descricao_comment);
        }
    }

    private void getUserInfo(ImageView imageView, TextView username, String idCriador){
        DocumentReference documentReference = db.collection("Usuarios").document(idCriador);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if(FirebaseAuth.getInstance().getCurrentUser() != null) {
                    Usuario usuario = value.toObject(Usuario.class);
                    if (usuario.getPrfUri() != null) {
                        Picasso.get().load(usuario.getPrfUri()).into(imageView);
                    }else{
                        imageView.setImageResource(R.drawable.noprfoto);
                    }
                    username.setText(usuario.getNome());
                }
            }
        });
    }
}
