package com.example.arenasocial.Classes;

import java.util.ArrayList;
import java.util.Date;

public class Torcedor extends Usuario{
    ArrayList<String> listaTimes= new ArrayList<>();

}
