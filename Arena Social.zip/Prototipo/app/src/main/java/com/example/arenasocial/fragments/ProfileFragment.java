package com.example.arenasocial.fragments;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.arenasocial.Adapter.PostAdapter;
import com.example.arenasocial.Adapter.UserAdapterInterface;
import com.example.arenasocial.BancoDados;
import com.example.arenasocial.Classes.Post;
import com.example.arenasocial.LoginActivity;
import com.example.arenasocial.R;
import com.example.arenasocial.SelecteamActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {
    private Toolbar toolbar;
    private TextView nomeUser,tvTime, tvModalidade;
    private ImageButton btImg;
    private Button btSelecteam;
    private ShapeableImageView prfImg;
    private CircleImageView teamImg;
    private ArrayList<Post> postArrayList = new ArrayList<Post>();
    private PostAdapter postAdapter = new PostAdapter(getActivity(), postArrayList);
    private RecyclerView recyclerView;
    private Spinner spModalidade;
    private SwipeRefreshLayout swipeRefreshLayout;
    com.example.arenasocial.databinding.FragmentProfileBinding binding;
    BancoDados db = new BancoDados();
    FirebaseFirestore fs = FirebaseFirestore.getInstance();
    String usuarioId = FirebaseAuth.getInstance().getCurrentUser().getUid();
    String tipo;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = com.example.arenasocial.databinding.FragmentProfileBinding.inflate(inflater, container, false);
        initComponents();
        adapterSpinner();
        postArrayList.clear();
        searchPosts();

        btSelecteam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SelecteamActivity.class);
                startActivity(intent);
            }
        });

        btImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 3);
            }
        });

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.deslogar){
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    getActivity().finish();
                    startActivity(intent);
                    db.deslogar();
                }
                return false;
            }
        });

        spModalidade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                db.saveModalidade(adapterView.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                db.saveModalidade(adapterView.getItemAtPosition(0).toString());
            }
        });

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                postAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        return binding.getRoot();
    }

    @Override
    public void onStart() {
        super.onStart();
        DocumentReference documentReference = fs.collection("Usuarios").document(usuarioId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if(documentSnapshot != null){
                    nomeUser.setText(documentSnapshot.getString("nome"));
                    Picasso.get().load(documentSnapshot.getString("prfUri")).into(prfImg);
                    if(documentSnapshot.getString("tipo").equals("Jogador")){
                        tvTime.setText("Time que joga:");
                    }
                    if(documentSnapshot.getString("tipo").equals("Time")){
                        tvTime.setText("Proximo jogo:");
                    }
                }
            }
        });
        DocumentReference documentRef = fs.collection("Usuarios").document(usuarioId);
        documentRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if(documentSnapshot != null && documentSnapshot.getString("timeFav") != null){
                    fs.collection("Usuarios").whereEqualTo("nome", documentSnapshot.getString("timeFav")).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Picasso.get().load(document.getString("prfUri")).into(teamImg);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            prfImg.setImageURI(selectedImage);
            btImg.setAlpha(0);
            db.saveUsrPhoto(selectedImage);
        }
    }

    private void searchPosts(){
        fs = FirebaseFirestore.getInstance();
        fs.collection("Posts").orderBy("timestamp").whereEqualTo("idCriador", usuarioId).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if(error != null){
                    Log.e("Firestore error", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()){
                    if (dc.getType() == DocumentChange.Type.ADDED){
                        postArrayList.add(dc.getDocument().toObject(Post.class));
                    }
                    postAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void adapterSpinner() {
        final ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
                getActivity(),R.layout.spinnerev_item){};

        DocumentReference documentReference = fs.collection("Usuarios").document(usuarioId);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if(documentSnapshot != null){
                    spinnerArrayAdapter.clear();
                    tipo = documentSnapshot.getString("tipo");
                    if(tipo.equals("Jogador")){
                        tvModalidade.setText("Posição:");
                        spinnerArrayAdapter.add("Atacante");
                        spinnerArrayAdapter.add("Meio-Campo");
                        spinnerArrayAdapter.add("Volante");
                        spinnerArrayAdapter.add("Zagueiro");
                        spinnerArrayAdapter.add("Goleiro");
                    }else{
                        spinnerArrayAdapter.add("Futebol");
                        spinnerArrayAdapter.add("Futsal");
                        spinnerArrayAdapter.add("Fut 7");
                        spinnerArrayAdapter.add("Futebol fe");
                    }
                }
            }
        });

        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);

        spModalidade.setAdapter(spinnerArrayAdapter);
    }

    private void initComponents(){
        nomeUser = binding.tvNomeUser;
        tvTime = binding.tvTimeFav;
        btImg = binding.userImg;
        toolbar = binding.tbToolbar;
        tvModalidade = binding.tvModalidade;
        spModalidade = binding.spModalidade;
        prfImg = binding.prfImg;
        btSelecteam = binding.btSelecteam;
        teamImg = binding.btIvTeam;
        recyclerView = binding.rcPrf;
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setAdapter(postAdapter);
        recyclerView.setLayoutManager(linearLayoutManager);
        swipeRefreshLayout = binding.swipeRefreshProfile;
    }

}